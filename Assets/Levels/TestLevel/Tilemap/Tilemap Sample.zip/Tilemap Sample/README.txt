Image Based Map Editor
----------------------

-Use image editor with transparency and pixel grid(preferably paint.net or Photoshop)
-Use layers in order of level layers (bottom to top, see example images)
-Create a key for what kind of block each color represents
	-RGBA(red, green, blue, alpha) values MUST be exact for the blocks to be loaded.
	-Specify EXACT blocks, the example only uses two, but specify styles, floor, ceiling,
	button wall, door, etc.
	-Use a color for enemy types as well.
-The player will spawn looking directly to the right. Keep this in mind for the angle of your
level.